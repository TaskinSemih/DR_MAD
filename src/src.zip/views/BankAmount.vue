<template>
  <div>
    <slot name="account-amount"></slot>
  </div>
</template>

<script>
export default {
  name: 'BankAmount',
}
</script>