<template>
  <span>Bienvenue à la banque</span>

</template>
